README for crosswalk file cw_ctycd108_ctycd109.dta
David Dorn

Notes:
This crosswalk covers only the states that updated district boundaries for the 109th Congress: Maine, Pennsylvania and Texas. The variable "ctycd108" identifies each spatial overlap between a county and a district of the 108th Congress, while "ctycd109" indicates the corresponding information for districts of the 109th Congress. The first two digits of these variables indicate the state FIPS code, the next three digits are the county FIPS code within the state, and the last two digits are the district within the state. The variable "cty_fips_2000" provides county codes where the first two digits indicate the state FIPS code and the last three digits indicate the county FIPS code within a state.The variable "afact_ctycd108_ctycd109" indicates the fraction of residents of a county-district cell of the 108th Congress who reside in a given county-district cell of the 109th Congress, while "afact_ctycd109_ctycd108" indicates the converse. These weights are based on the population structure of the 2000 Census.

Please cite as source for this file:
David Autor, David Dorn, Gordon Hanson and Kaveh Majlesi. "Importing Political Polarization? The Electoral Consequences of Rising Trade Exposure."
American Economic Review, 110(10): 3139-3189, 2020.

