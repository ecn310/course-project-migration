README for crosswalk file cw_cd108_cd113.dta
David Dorn

Notes:
The variable "afact_cd108_cd113" indicates the fraction of residents of a district of the 108th Congress who reside in a given district of the 113th Congress, while "afact_cd109_cd113" indicates the converse. These weights are based on the population structure of the 2000 Census. 

Please cite as source for this file:
David Autor, David Dorn, Gordon Hanson and Kaveh Majlesi. "Importing Political Polarization? The Electoral Consequences of Rising Trade Exposure."
American Economic Review, 110(10): 3139-3189, 2020.

