README for cw_cd108_cd115.dta
David Dorn

Notes:
This crosswalk covers only the states that updated district boundaries for the 115th Congress: Florida, North Carolina and Virginia. The variable "afact_cd108_cd115" indicates the fraction of residents of a district of the 108th Congress who reside in a given district of the 115th Congress, while "afact_cd109_cd115" indicates the converse. These weights are based on the population structure of the 2000 Census. 


Please cite as source for this file:
David Autor, David Dorn, Gordon Hanson and Kaveh Majlesi. "Importing Political Polarization? The Electoral Consequences of Rising Trade Exposure."
American Economic Review, 110(10): 3139-3189, 2020.

