README for cw_ctycd108_ctycd115.dta
David Dorn

Notes:
This crosswalk covers only the states that updated district boundaries for the 115th Congress: Florida, North Carolina and Virginia. The variable "ctycd108" identifies each spatial overlap between a county and a district of the 108th Congress, while "ctycd115" indicates the corresponding information for districts of the 115th Congress. The first two digits of these variables indicate the state FIPS code, the next three digits are the county FIPS code within the state, and the last two digits are the district within the state. The variables "cty_fips_2000" and "cty_fips_2010" provide county codes for the years 2000 and 2010, where the first two digits indicate the state FIPS code and the last three digits indicate the county FIPS code within a state. These two variables almost always coincide, except in rare cases where counties split, merged or were renamed, or in case of minor boundary changes between counties. The variable "afact_ctycd108_ctycd115" indicates the fraction of residents of a county-district cell of the 108th Congress who reside in a given county-district cell of the 115th Congress, while "afact_ctycd115_ctycd108" indicates the converse. These weights are based on the population structure of the 2000 Census.


Please cite as source for this file:
David Autor, David Dorn, Gordon Hanson and Kaveh Majlesi. "Importing Political Polarization? The Electoral Consequences of Rising Trade Exposure."
American Economic Review, 110(10): 3139-3189, 2020.

